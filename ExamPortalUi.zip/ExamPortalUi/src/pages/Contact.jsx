import React, { useState } from "react";

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div style={{ maxWidth: 500, margin: '3rem auto', padding: '2rem', background: '#fff', borderRadius: 16, boxShadow: '0 4px 24px rgba(99,102,241,0.08)' }}>
      <h2 style={{ fontWeight: 700, fontSize: '2rem', color: '#6366f1', marginBottom: 16 }}>Contact Us</h2>
      {submitted ? (
        <div style={{ color: '#10b981', fontWeight: 600, fontSize: '1.1rem' }}>Thank you for contacting us! We'll get back to you soon.</div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', marginBottom: 6, color: '#374151' }}>Name</label>
            <input type="text" name="name" value={form.name} onChange={handleChange} required style={{ width: '100%', padding: 10, borderRadius: 8, border: '1px solid #d1d5db' }} />
          </div>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', marginBottom: 6, color: '#374151' }}>Email</label>
            <input type="email" name="email" value={form.email} onChange={handleChange} required style={{ width: '100%', padding: 10, borderRadius: 8, border: '1px solid #d1d5db' }} />
          </div>
          <div style={{ marginBottom: 24 }}>
            <label style={{ display: 'block', marginBottom: 6, color: '#374151' }}>Message</label>
            <textarea name="message" value={form.message} onChange={handleChange} required rows={4} style={{ width: '100%', padding: 10, borderRadius: 8, border: '1px solid #d1d5db' }} />
          </div>
          <button type="submit" style={{ background: 'linear-gradient(90deg, #6366f1 0%, #a5b4fc 100%)', color: '#fff', fontWeight: 600, padding: '0.7rem 2rem', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: '1rem' }}>Send Message</button>
        </form>
      )}
    </div>
  );
};

export default Contact; 