namespace ExamPortal.Models
{
    public enum UserRole
    {
        STUDENT,
        TEACHER
    }
}
