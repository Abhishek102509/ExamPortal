package com.examportal.entities;

public enum UserRole {
    STUDENT, TEACHER
}
