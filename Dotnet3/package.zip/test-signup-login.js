// Test script to create a user and test login flow
const axios = require('axios');

const API_BASE_URL = "http://localhost:5113/api";

async function testSignup() {
    try {
        console.log('Testing user signup...');
        
        const signupData = {
            username: "testuser001",
            email: "testuser001@example.com",
            password: "Test123!",
            firstName: "Test",
            lastName: "User",
            role: 1 // Assuming 1 is STUDENT
        };
        
        const response = await axios.post(`${API_BASE_URL}/auth/signup`, signupData);
        console.log('✅ Signup successful!');
        console.log('Response:', response.data);
        
        return signupData;
        
    } catch (error) {
        console.log('❌ Signup failed:', error.response?.data || error.message);
        return null;
    }
}

async function testLogin(credentials) {
    try {
        console.log('\nTesting login with created user...');
        
        const loginData = {
            emailOrUsername: credentials.username,
            password: credentials.password
        };
        
        const response = await axios.post(`${API_BASE_URL}/auth/signin`, loginData);
        console.log('✅ Login successful!');
        console.log('Response structure:', {
            token: response.data.token ? 'Present ✅' : 'Missing ❌',
            tokenType: response.data.tokenType,
            user: response.data.user ? 'Present ✅' : 'Missing ❌'
        });
        
        if (response.data.user) {
            console.log('User details:', {
                id: response.data.user.id,
                username: response.data.user.username,
                email: response.data.user.email,
                role: response.data.user.role,
                firstName: response.data.user.firstName,
                lastName: response.data.user.lastName
            });
        }
        
        return response.data;
        
    } catch (error) {
        console.log('❌ Login failed:', error.response?.data || error.message);
        return null;
    }
}

async function testAuthenticatedRequest(authData) {
    if (!authData || !authData.token) {
        console.log('\nNo token available for testing authenticated requests');
        return;
    }
    
    try {
        console.log('\nTesting authenticated request...');
        
        const response = await axios.get(`${API_BASE_URL}/users`, {
            headers: {
                'Authorization': `Bearer ${authData.token}`
            }
        });
        
        console.log('✅ Authenticated request successful!');
        console.log('Users count:', response.data.length);
        
    } catch (error) {
        console.log('❌ Authenticated request failed:', error.response?.data || error.message);
    }
}

async function runTests() {
    console.log('=== Frontend-Backend API Connection Test ===\n');
    
    const signupData = await testSignup();
    if (!signupData) {
        console.log('\nTrying to login with possible existing test user...');
        const testCredentials = {
            username: "testuser001",
            password: "Test123!"
        };
        const authData = await testLogin(testCredentials);
        await testAuthenticatedRequest(authData);
    } else {
        const authData = await testLogin(signupData);
        await testAuthenticatedRequest(authData);
    }
    
    console.log('\n=== Summary ===');
    console.log('If tests were successful, the frontend should now be able to:');
    console.log('1. Create new users via signup');
    console.log('2. Login with created users');
    console.log('3. Make authenticated API calls');
    console.log('\nFrontend configuration is correct:');
    console.log('- API Base URL: http://localhost:5113/api');
    console.log('- AuthContext expects: { token, user } structure');
}

runTests();
