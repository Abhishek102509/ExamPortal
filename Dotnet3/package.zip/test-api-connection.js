// Test script to verify API connection between frontend and backend
const axios = require('axios');

const API_BASE_URL = "http://localhost:5113/api";

async function testApiConnection() {
    console.log("Testing API connection...");
    console.log("Backend URL:", API_BASE_URL);
    
    try {
        // Test basic connectivity
        const response = await axios.get(`${API_BASE_URL}/auth/test`, {
            timeout: 5000
        });
        console.log("✅ API connection successful!");
        console.log("Response:", response.data);
    } catch (error) {
        if (error.code === 'ECONNREFUSED') {
            console.log("❌ Connection refused - Backend server is not running on port 5113");
            console.log("Please start your .NET backend server first");
        } else if (error.response) {
            console.log("✅ Server is responding (got HTTP error):");
            console.log(`Status: ${error.response.status} - ${error.response.statusText}`);
            if (error.response.status === 404) {
                console.log("This is expected if /auth/test endpoint doesn't exist");
            }
        } else {
            console.log("❌ Network error:", error.message);
        }
    }
}

// Test authentication endpoints
async function testAuthEndpoints() {
    console.log("\n=== Testing Authentication Endpoints ===");
    
    // Test login with test credentials    
    const testCredentials = [
        { emailOrUsername: "admin", password: "admin123", role: "TEACHER" },
        { emailOrUsername: "student", password: "student123", role: "STUDENT" },
        { emailOrUsername: "testuser", password: "password", role: "STUDENT" }
    ];
    
    for (const creds of testCredentials) {
        try {
            console.log(`Testing login with ${creds.emailOrUsername}...`);
            
            const response = await axios.post(`${API_BASE_URL}/auth/signin`, creds, {
                timeout: 5000
            });
            
            console.log(`✅ Login successful for ${creds.emailOrUsername} (${creds.role})`);
            console.log(`   Token received: ${response.data.token ? 'YES' : 'NO'}`);
            console.log(`   User data: ${response.data.user ? 'YES' : 'NO'}`);
            
            if (response.data.user) {
                console.log(`   Role: ${response.data.user.role}`);
            }
            
            return response.data.token; // Return token for further testing
            
        } catch (error) {
            if (error.response) {
                console.log(`❌ Login failed for ${creds.emailOrUsername}: HTTP ${error.response.status}`);
                if (error.response.data) {
                    console.log(`   Error: ${error.response.data.message || JSON.stringify(error.response.data)}`);
                }
            } else if (error.code === 'ECONNREFUSED') {
                console.log(`❌ Server not running`);
                return null;
            } else {
                console.log(`❌ Network error: ${error.message}`);
            }
        }
    }
    
    return null;
}

// Test specific endpoints that your frontend uses
async function testSpecificEndpoints(token = null) {
    console.log("\n=== Testing Protected Endpoints ===");
    
    const endpoints = [
        { method: 'GET', url: '/exams/active', description: 'Get active exams' },
        { method: 'GET', url: '/exams/upcoming', description: 'Get upcoming exams' },
    ];
    
    const headers = token ? { Authorization: `Bearer ${token}` } : {};
    
    for (const endpoint of endpoints) {
        try {
            console.log(`Testing ${endpoint.method} ${endpoint.url}...`);
            
            if (endpoint.method === 'GET') {
                const response = await axios.get(`${API_BASE_URL}${endpoint.url}`, {
                    timeout: 5000,
                    headers
                });
                console.log(`✅ ${endpoint.description} - Success`);
            }
        } catch (error) {
            if (error.response) {
                console.log(`⚠️  ${endpoint.description} - HTTP ${error.response.status}`);
                if (error.response.status === 401) {
                    console.log("   (Authentication required - this is expected without token)");
                }
            } else if (error.code === 'ECONNREFUSED') {
                console.log(`❌ ${endpoint.description} - Server not running`);
                break;
            } else {
                console.log(`❌ ${endpoint.description} - ${error.message}`);
            }
        }
    }
}

async function main() {
    await testApiConnection();
    await testSpecificEndpoints();
    
    console.log("\n=== Instructions ===");
    console.log("1. Make sure your .NET backend is running on port 5113");
    console.log("2. Run your backend with: dotnet run (from ExamPortal directory)");
    console.log("3. Run your frontend with: npm run dev (from Exam directory)");
    console.log("4. Your frontend will be available at: http://localhost:5173 (or another port shown by Vite)");
}

main();
