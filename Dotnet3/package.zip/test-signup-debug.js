// Detailed test to debug signup issues
const axios = require('axios');

const API_BASE_URL = "http://localhost:5113/api";

async function testSignupWithStringRole() {
    try {
        console.log('Testing signup with string role (like frontend sends)...');
        
        const signupData = {
            username: "testuser002",
            email: "testuser002@example.com",
            password: "Test123!",
            firstName: "Test",
            lastName: "User",
            role: "STUDENT" // String value like frontend sends
        };
        
        console.log('Sending data:', signupData);
        
        const response = await axios.post(`${API_BASE_URL}/auth/signup`, signupData);
        console.log('✅ Signup successful!');
        console.log('Response:', response.data);
        
    } catch (error) {
        console.log('❌ Signup failed with string role');
        console.log('Status:', error.response?.status);
        console.log('Full error data:', error.response?.data);
        console.log('Error message:', error.message);
    }
}

async function testSignupWithNumericRole() {
    try {
        console.log('\nTesting signup with numeric role...');
        
        const signupData = {
            username: "testuser003",
            email: "testuser003@example.com",
            password: "Test123!",
            firstName: "Test",
            lastName: "User",
            role: 0 // 0 = STUDENT, 1 = TEACHER
        };
        
        console.log('Sending data:', signupData);
        
        const response = await axios.post(`${API_BASE_URL}/auth/signup`, signupData);
        console.log('✅ Signup successful with numeric role!');
        console.log('Response:', response.data);
        
        return signupData;
        
    } catch (error) {
        console.log('❌ Signup failed with numeric role');
        console.log('Status:', error.response?.status);
        console.log('Full error data:', error.response?.data);
        console.log('Error message:', error.message);
        return null;
    }
}

async function testLoginWithNewUser(signupData) {
    if (!signupData) return;
    
    try {
        console.log('\nTesting login with newly created user...');
        
        const loginData = {
            emailOrUsername: signupData.username,
            password: signupData.password
        };
        
        console.log('Login data:', loginData);
        
        const response = await axios.post(`${API_BASE_URL}/auth/signin`, loginData);
        console.log('✅ Login successful!');
        console.log('Auth response structure:');
        console.log({
            hasToken: !!response.data.token,
            tokenType: response.data.tokenType,
            hasUser: !!response.data.user,
            userRole: response.data.user?.role
        });
        
    } catch (error) {
        console.log('❌ Login failed');
        console.log('Status:', error.response?.status);
        console.log('Error data:', error.response?.data);
    }
}

async function runDetailedTests() {
    console.log('=== Detailed Frontend-Backend Connection Debug ===\n');
    
    await testSignupWithStringRole();
    const newUser = await testSignupWithNumericRole();
    await testLoginWithNewUser(newUser);
    
    console.log('\n=== Analysis ===');
    console.log('If string role fails but numeric role works, then:');
    console.log('- Frontend needs to convert role string to number');
    console.log('- "STUDENT" = 0, "TEACHER" = 1');
}

runDetailedTests();
