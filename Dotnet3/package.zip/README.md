# Exam Portal - Backend & Frontend Connection Guide

This project consists of a .NET Core backend API and a React frontend that need to be connected properly.

## Project Structure
```
Dotnet3/
├── ExamPortal/          # .NET Core Backend API
├── Exam/                # React Frontend
├── start-both.ps1       # Script to start both services
├── test-api-connection.js # API connection test script
└── README.md           # This file
```

## ✅ What I've Fixed

### 1. API Base URL Configuration
- **Fixed**: Updated frontend API base URL from `http://localhost:8080/api` to `http://localhost:5113/api`
- **File**: `Exam/src/services/api.js`

### 2. Controller Route Mappings
Fixed all backend controller routes to match frontend API calls:
- **AuthController**: `api/auth` ✅ (already correct)
- **UserController**: `api/user` → `api/users` ✅
- **ExamController**: `api/exam` → `api/exams` ✅
- **QuestionController**: `api/question` → `api/questions` ✅
- **StudentQueryController**: `api/studentquery` → `api/queries` ✅

### 3. CORS Configuration
- **Enhanced**: Added specific CORS policy for frontend origins
- **Added**: Support for common development ports (5173, 3000, 5174)

## 🚀 How to Run the Application

### Option 1: Using the PowerShell Script (Recommended)
```powershell
# Navigate to the project root directory
cd "C:\Users\abhi1\OneDrive\Desktop\Final Project\Dotnet3"

# Run the startup script
.\start-both.ps1
```

### Option 2: Manual Setup

#### Step 1: Start the Backend (.NET API)
```bash
# Navigate to backend directory
cd ExamPortal

# Restore packages (first time only)
dotnet restore

# Run database migrations (first time only)
dotnet ef database update

# Start the backend server
dotnet run
```
**Backend will be available at:** `http://localhost:5113`
**API Documentation (Swagger):** `http://localhost:5113/swagger`

#### Step 2: Start the Frontend (React)
```bash
# Open a new terminal and navigate to frontend directory
cd Exam

# Install dependencies (first time only)
npm install

# Start the development server
npm run dev
```
**Frontend will be available at:** `http://localhost:5173` (or next available port)

## 🧪 Testing the Connection

### Test API Connection
```bash
# Install axios for the test script (if not already installed)
npm install axios

# Run the connection test
node test-api-connection.js
```

### Manual Testing
1. Open browser to `http://localhost:5173`
2. Try to sign up/login
3. Check browser Developer Tools → Network tab for API calls
4. Verify API calls are going to `http://localhost:5113/api`

## 📋 API Endpoints Overview

### Authentication
- `POST /api/auth/signup` - User registration
- `POST /api/auth/signin` - User login

### Users
- `GET /api/users/profile` - Get current user profile
- `GET /api/users` - Get all users (Teacher only)
- `PUT /api/users/{id}` - Update user (Teacher only)
- `DELETE /api/users/{id}` - Delete user (Teacher only)

### Exams
- `GET /api/exams` - Get all exams (Teacher only)
- `POST /api/exams` - Create exam (Teacher only)
- `GET /api/exams/{id}` - Get exam by ID
- `PUT /api/exams/{id}` - Update exam (Teacher only)
- `DELETE /api/exams/{id}` - Delete exam (Teacher only)
- `GET /api/exams/active` - Get active exams
- `GET /api/exams/upcoming` - Get upcoming exams
- `POST /api/exams/submit` - Submit exam (Student only)
- `GET /api/exams/results/my` - Get my results (Student only)

### Questions
- `POST /api/questions` - Create question (Teacher only)
- `GET /api/questions/exam/{examId}` - Get questions by exam
- `PUT /api/questions/{id}` - Update question (Teacher only)
- `DELETE /api/questions/{id}` - Delete question (Teacher only)

### Student Queries
- `POST /api/queries` - Submit query (Student only)
- `GET /api/queries` - Get all queries (Teacher only)
- `GET /api/queries/my` - Get my queries (Student only)
- `PUT /api/queries/{id}` - Update query (Teacher only)
- `DELETE /api/queries/{id}` - Delete query (Teacher only)

## 🛠️ Troubleshooting

### Common Issues

1. **Connection Refused Error**
   - Make sure the backend is running on port 5113
   - Check if another application is using port 5113

2. **CORS Errors**
   - Verify frontend is running on port 5173, 3000, or 5174
   - Check browser console for specific CORS error messages

3. **Authentication Errors**
   - Ensure JWT tokens are being stored in localStorage
   - Check if token is being sent in Authorization header

4. **Database Errors**
   - Run `dotnet ef database update` in the ExamPortal directory
   - Check connection string in `appsettings.json`

### Port Configuration
- **Backend**: `http://localhost:5113`
- **Frontend**: `http://localhost:5173` (default Vite port)
- **Alternative Frontend Ports**: 3000, 5174 (configured in CORS)

### Environment Variables
The backend uses the following configuration:
- **Database**: LocalDB (SQL Server)
- **JWT Secret**: Configured in `appsettings.json`
- **Environment**: Development

## 📝 Development Notes

- The frontend uses Axios for HTTP requests with automatic JWT token handling
- The backend implements JWT authentication with role-based authorization
- CORS is configured to allow requests from common development ports
- All API responses use standardized DTOs for consistent data structure

## 🔐 Authentication Flow

1. User signs up/logs in via frontend
2. Backend validates credentials and returns JWT token
3. Frontend stores token in localStorage
4. All subsequent API requests include the token in Authorization header
5. Backend validates token and authorizes requests based on user roles

## 📚 Tech Stack

**Backend (.NET Core 8)**
- ASP.NET Core Web API
- Entity Framework Core
- SQL Server LocalDB
- JWT Authentication
- AutoMapper
- FluentValidation
- Swagger/OpenAPI

**Frontend (React 18)**
- React with Vite
- React Router DOM
- Axios for HTTP requests
- Bootstrap for styling
- React Hot Toast for notifications
