const axios = require('axios');

const API_BASE_URL = "http://localhost:5113/api";

async function testAuthentication() {
    console.log("=== Testing Authentication Endpoints ===");
    
    // Test credentials that should exist in the seeded database
    const testCredentials = [
        { emailOrUsername: "admin", password: "admin123" },
        { emailOrUsername: "student", password: "student123" },
        { emailOrUsername: "testuser", password: "password" }
    ];
    
    for (const creds of testCredentials) {
        console.log(`\nTesting login with ${creds.emailOrUsername}...`);
        
        try {
            const response = await axios.post(`${API_BASE_URL}/auth/signin`, creds, {
                timeout: 5000
            });
            
            console.log(`✅ Login successful for ${creds.emailOrUsername}`);
            console.log(`   Token received: ${response.data.token ? 'YES' : 'NO'}`);
            console.log(`   User data: ${response.data.user ? 'YES' : 'NO'}`);
            console.log(`   Response structure:`, Object.keys(response.data));
            
            if (response.data.user) {
                console.log(`   User role: ${response.data.user.role}`);
                console.log(`   User ID: ${response.data.user.id}`);
            }
            
            // Test with this token
            if (response.data.token) {
                await testWithToken(response.data.token);
            }
            
            return response.data; // Success, return for further testing
            
        } catch (error) {
            if (error.response) {
                console.log(`❌ Login failed for ${creds.emailOrUsername}: HTTP ${error.response.status}`);
                console.log(`   Error message:`, error.response.data);
            } else if (error.code === 'ECONNREFUSED') {
                console.log(`❌ Server not running`);
                return null;
            } else {
                console.log(`❌ Network error: ${error.message}`);
            }
        }
    }
    
    return null;
}

async function testWithToken(token) {
    console.log(`\n  Testing protected endpoint with token...`);
    
    try {
        const response = await axios.get(`${API_BASE_URL}/users/profile`, {
            headers: {
                'Authorization': `Bearer ${token}`
            },
            timeout: 5000
        });
        
        console.log(`  ✅ Protected endpoint works with token`);
        console.log(`     Profile data:`, response.data);
        
    } catch (error) {
        if (error.response) {
            console.log(`  ❌ Protected endpoint failed: HTTP ${error.response.status}`);
            if (error.response.data) {
                console.log(`     Error:`, error.response.data);
            }
        } else {
            console.log(`  ❌ Network error: ${error.message}`);
        }
    }
}

async function testCoverAPI() {
    console.log("\n=== Testing Coverr API (the 401 error you mentioned) ===");
    
    try {
        // This is the URL from your error message
        const response = await axios.get("https://api.coverr.co/videos/random?category=nature:1", {
            timeout: 5000
        });
        
        console.log("✅ Coverr API works fine");
        console.log("Response:", response.data);
        
    } catch (error) {
        if (error.response?.status === 401) {
            console.log("❌ Coverr API requires authentication");
            console.log("This API might require an API key or authentication header");
            console.log("Check Coverr API documentation for authentication requirements");
        } else if (error.response) {
            console.log(`❌ Coverr API error: HTTP ${error.response.status}`);
            console.log("Error:", error.response.data);
        } else {
            console.log(`❌ Network error: ${error.message}`);
        }
    }
}

async function main() {
    await testAuthentication();
    await testCoverAPI();
}

main();
