const axios = require('axios');
const bcrypt = require('bcrypt');

const API_BASE_URL = "http://localhost:5113/api";

// Simulate what BCrypt.Net does on C# side
function testPasswords() {
    console.log("=== Testing Password Hashing ===");
    
    const testPasswords = ["admin123", "student123", "password"];
    
    testPasswords.forEach(password => {
        const hash = bcrypt.hashSync(password, 10);
        console.log(`Password: ${password}`);
        console.log(`Hash: ${hash}`);
        console.log(`Verify: ${bcrypt.compareSync(password, hash)}`);
        console.log('---');
    });
}

async function testWithDifferentFormats() {
    console.log("\n=== Testing Different Login Formats ===");
    
    const testAttempts = [
        // Username based
        { emailOrUsername: "admin", password: "admin123" },
        { emailOrUsername: "student", password: "student123" },
        { emailOrUsername: "testuser", password: "password" },
        
        // Email based
        { emailOrUsername: "admin@example.com", password: "admin123" },
        { emailOrUsername: "student@example.com", password: "student123" },
        { emailOrUsername: "test@example.com", password: "password" },
    ];
    
    for (const creds of testAttempts) {
        console.log(`\nTrying: ${creds.emailOrUsername} / ${creds.password}`);
        
        try {
            const response = await axios.post(`${API_BASE_URL}/auth/signin`, creds, {
                timeout: 5000
            });
            
            console.log(`✅ SUCCESS!`);
            console.log(`   Token: ${response.data.token ? 'YES' : 'NO'}`);
            console.log(`   User: ${response.data.user ? response.data.user.username : 'NO'}`);
            console.log(`   Role: ${response.data.user ? response.data.user.role : 'NO'}`);
            
            return response.data; // Return first successful login
            
        } catch (error) {
            if (error.response) {
                console.log(`❌ HTTP ${error.response.status}: ${error.response.data?.message || 'Unknown error'}`);
            } else {
                console.log(`❌ Network error: ${error.message}`);
            }
        }
    }
    
    return null;
}

async function testSignup() {
    console.log("\n=== Testing Signup (to verify API is working) ===");
    
    const newUser = {
        username: "testuser" + Date.now(),
        email: `test${Date.now()}@example.com`,
        password: "testpass123",
        firstName: "Test",
        lastName: "User",
        role: 0  // STUDENT = 0, TEACHER = 1
    };
    
    try {
        const response = await axios.post(`${API_BASE_URL}/auth/signup`, newUser, {
            timeout: 5000
        });
        
        console.log("✅ Signup successful!");
        console.log("   User created:", response.data.username);
        
        // Now try to login with this new user
        console.log("\n  Testing login with newly created user...");
        const loginResponse = await axios.post(`${API_BASE_URL}/auth/signin`, {
            emailOrUsername: newUser.username,
            password: newUser.password
        });
        
        console.log("  ✅ Login with new user successful!");
        console.log(`     Token: ${loginResponse.data.token ? 'YES' : 'NO'}`);
        
        return loginResponse.data;
        
    } catch (error) {
        if (error.response) {
            console.log(`❌ Signup failed: HTTP ${error.response.status}`);
            console.log(`   Error:`, error.response.data);
        } else {
            console.log(`❌ Network error: ${error.message}`);
        }
    }
    
    return null;
}

async function main() {
    testPasswords();
    const loginResult = await testWithDifferentFormats();
    
    if (!loginResult) {
        console.log("\n⚠️  All seeded users failed. Trying to create a new user...");
        await testSignup();
    }
}

main();
