-- Check if users exist in the database
USE ExamPortalDb;
SELECT COUNT(*) as UserCount FROM Users;
SELECT * FROM Users;
