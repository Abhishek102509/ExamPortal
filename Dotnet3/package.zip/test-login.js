// Test script to verify login with seed user credentials
const axios = require('axios');

const API_BASE_URL = "http://localhost:5113/api";

async function testLogin() {
    try {
        console.log('Testing login with seed user credentials...');
        
        const testCredentials = {
            emailOrUsername: "admin",
            password: "admin123"
        };
        
        const response = await axios.post(`${API_BASE_URL}/auth/signin`, testCredentials);
        console.log('✅ Login successful!');
        console.log('Response structure:', {
            token: response.data.token ? 'Present ✅' : 'Missing ❌',
            tokenType: response.data.tokenType,
            user: response.data.user ? 'Present ✅' : 'Missing ❌'
        });
        
        if (response.data.user) {
            console.log('User details:', {
                id: response.data.user.id,
                username: response.data.user.username,
                email: response.data.user.email,
                role: response.data.user.role,
                firstName: response.data.user.firstName,
                lastName: response.data.user.lastName
            });
        }
        
        return response.data;
        
    } catch (error) {
        console.log('❌ Login failed:', error.response?.data || error.message);
        return null;
    }
}

async function testWithToken(authData) {
    if (!authData || !authData.token) {
        console.log('No token available for testing');
        return;
    }
    
    try {
        console.log('\nTesting authenticated request...');
        
        const response = await axios.get(`${API_BASE_URL}/users`, {
            headers: {
                'Authorization': `Bearer ${authData.token}`
            }
        });
        
        console.log('✅ Authenticated request successful!');
        console.log('Users count:', response.data.length);
        
    } catch (error) {
        console.log('❌ Authenticated request failed:', error.response?.data || error.message);
    }
}

async function runTests() {
    const authData = await testLogin();
    await testWithToken(authData);
    
    console.log('\n=== Test Results ===');
    console.log('Frontend should now be able to login with:');
    console.log('Username: admin');
    console.log('Password: admin123');
    console.log('or any of the other seed users listed in the backend logs');
}

runTests();
