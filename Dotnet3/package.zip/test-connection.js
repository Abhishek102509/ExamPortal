// Test script to verify frontend-backend connection
const axios = require('axios');

const API_BASE_URL = "http://localhost:5113/api";

async function testConnection() {
    try {
        console.log('Testing API connection...');
        
        // Test basic connectivity
        const response = await axios.get(`${API_BASE_URL}/users`);
        console.log('✅ API connection successful');
        console.log('Response status:', response.status);
        
    } catch (error) {
        if (error.code === 'ECONNREFUSED') {
            console.log('❌ Connection refused - Backend server might not be running');
            console.log('Make sure to start the backend server first:');
            console.log('cd ExamPortal && dotnet run');
        } else if (error.response) {
            console.log('✅ API is reachable but returned an error:');
            console.log('Status:', error.response.status);
            console.log('Message:', error.response.data);
        } else {
            console.log('❌ Unexpected error:', error.message);
        }
    }
}

// Test authentication endpoint
async function testAuth() {
    try {
        console.log('\nTesting authentication endpoint...');
        
        const testCredentials = {
            emailOrUsername: "test@example.com",
            password: "testpassword"
        };
        
        const response = await axios.post(`${API_BASE_URL}/auth/signin`, testCredentials);
        console.log('✅ Auth endpoint is working');
        console.log('Response:', response.data);
        
    } catch (error) {
        if (error.response && error.response.status === 401) {
            console.log('✅ Auth endpoint is working (returned 401 for invalid credentials)');
        } else if (error.response) {
            console.log('✅ Auth endpoint is reachable');
            console.log('Status:', error.response.status);
            console.log('Message:', error.response.data);
        } else {
            console.log('❌ Auth endpoint error:', error.message);
        }
    }
}

async function runTests() {
    await testConnection();
    await testAuth();
}

runTests();
