# PowerShell script to start both backend and frontend
Write-Host "=== Starting Exam Portal Backend and Frontend ===" -ForegroundColor Green

# Function to start backend
function Start-Backend {
    Write-Host "Starting .NET Backend..." -ForegroundColor Yellow
    Set-Location ".\ExamPortal"
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "dotnet run" -WindowStyle Normal
    Write-Host "Backend started on http://localhost:5113" -ForegroundColor Green
}

# Function to start frontend
function Start-Frontend {
    Write-Host "Starting React Frontend..." -ForegroundColor Yellow
    Set-Location "..\Exam"
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "npm run dev" -WindowStyle Normal
    Write-Host "Frontend will start on http://localhost:5173 (or next available port)" -ForegroundColor Green
}

# Main execution
try {
    $originalLocation = Get-Location
    
    Write-Host "Current directory: $originalLocation" -ForegroundColor Cyan
    
    # Start backend
    Start-Backend
    Start-Sleep -Seconds 3
    
    # Return to original location and start frontend
    Set-Location $originalLocation
    Start-Frontend
    
    Write-Host "`n=== Both services are starting! ===" -ForegroundColor Green
    Write-Host "Backend: http://localhost:5113/swagger (API documentation)" -ForegroundColor Cyan
    Write-Host "Frontend: http://localhost:5173 (React app)" -ForegroundColor Cyan
    Write-Host "`nPress any key to continue..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    
} catch {
    Write-Host "Error occurred: $($_.Exception.Message)" -ForegroundColor Red
} finally {
    Set-Location $originalLocation
}
