import React from "react";

const About = () => (
  <div style={{ maxWidth: 700, margin: '3rem auto', padding: '2rem', background: '#fff', borderRadius: 16, boxShadow: '0 4px 24px rgba(99,102,241,0.08)' }}>
    <h2 style={{ fontWeight: 700, fontSize: '2rem', color: '#6366f1', marginBottom: 16 }}>About Us</h2>
    <p style={{ fontSize: '1.1rem', color: '#374151' }}>
      Exam Portal is a modern online examination platform designed to simplify the process of conducting, taking, and managing exams for both students and teachers. Our mission is to provide a seamless, secure, and user-friendly experience for all users.
    </p>
    <ul style={{ marginTop: 24, color: '#4b5563', fontSize: '1rem' }}>
      <li>• Conduct online exams with ease</li>
      <li>• Instant results and analytics</li>
      <li>• Secure and reliable platform</li>
      <li>• Student-teacher interaction and support</li>
    </ul>
  </div>
);

export default About; 