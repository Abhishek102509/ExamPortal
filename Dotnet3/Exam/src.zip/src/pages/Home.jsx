import React, { useEffect, useState } from "react";

const DEFAULT_VIDEO =
  "https://videos.pexels.com/video-files/4148572/4148572-hd_1920_1080_25fps.mp4";

const Home = () => {
  const [videoUrl, setVideoUrl] = useState(DEFAULT_VIDEO);

  useEffect(() => {
    // Fetch a random video from Coverr API
    fetch("https://api.coverr.co/videos/random?category=nature")
      .then((res) => res.json())
      .then((data) => {
        if (data && data.videos && data.videos.length > 0) {
          setVideoUrl(data.videos[0].video_url);
        }
      })
      .catch(() => {
        setVideoUrl(DEFAULT_VIDEO); // fallback
      });
  }, []);

  return (
    <div
      style={{
        position: "relative",
        minHeight: "80vh",
        width: "100%",
        overflow: "hidden",
      }}
    >
      {/* Background Video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          objectFit: "cover",
          zIndex: 0,
          filter: "brightness(0.7)",
        }}
        src={videoUrl}
      />
      {/* Overlay for readability */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          background:
            "linear-gradient(135deg, rgba(224,231,255,0.7) 0%, rgba(240,253,250,0.7) 100%)",
          zIndex: 1,
        }}
      />
      {/* Content */}
      <div
        style={{
          position: "relative",
          zIndex: 2,
          minHeight: "80vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div
          style={{
            textAlign: "center",
            maxWidth: 600,
            background: "rgba(255,255,255,0.85)",
            borderRadius: 16,
            padding: "2.5rem 2rem",
            boxShadow: "0 4px 24px rgba(49,46,129,0.08)",
          }}
        >
          <h1
            style={{
              fontSize: "2.5rem",
              fontWeight: 700,
              color: "#312e81",
              marginBottom: 16,
            }}
          >
            Welcome to Exam Portal
          </h1>
          <p
            style={{
              fontSize: "1.2rem",
              color: "#4b5563",
              marginBottom: 32,
            }}
          >
            Your one-stop solution for online exams, results, and student-teacher
            interaction. Get started by logging in or signing up!
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home; 