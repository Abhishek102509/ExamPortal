import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => (
  <nav style={{
    width: '100%',
    background: 'linear-gradient(90deg, #6366f1 0%, #a5b4fc 100%)',
    padding: '0.75rem 0',
    position: 'sticky',
    top: 0,
    zIndex: 100,
    boxShadow: '0 2px 8px rgba(99,102,241,0.08)'
  }}>
    <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 2rem' }}>
      <div style={{ fontWeight: 700, fontSize: '1.3rem', color: '#fff', letterSpacing: 1 }}>Exam Portal</div>
      <div style={{ display: 'flex', gap: '1.5rem' }}>
        <Link to="/" style={navBtnStyle}>Home</Link>
        <Link to="/about" style={navBtnStyle}>About Us</Link>
        <Link to="/login" style={navBtnStyle}>Login</Link>
        <Link to="/signup" style={navBtnStyle}>Sign Up</Link>
        <Link to="/contact" style={navBtnStyle}>Contact Us</Link>
      </div>
    </div>
  </nav>
);

const navBtnStyle = {
  color: '#fff',
  fontWeight: 500,
  fontSize: '1rem',
  textDecoration: 'none',
  padding: '0.5rem 1.2rem',
  borderRadius: 8,
  transition: 'background 0.2s',
  background: 'rgba(255,255,255,0.08)',
  border: 'none',
  outline: 'none',
  cursor: 'pointer',
  display: 'inline-block',
};

export default Navbar; 